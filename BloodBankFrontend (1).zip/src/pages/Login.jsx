
export default function Login(){
 return <div><h2>Blood Bank Login</h2></div>
}
